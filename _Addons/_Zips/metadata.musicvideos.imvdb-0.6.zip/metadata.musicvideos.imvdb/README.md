metadata.musicvideos.imvdb
=============
This project is a scraper for use with Kodi, an open source home theatre system, that downloads music video information from the Internet Music Video Database (imvdb.com).
